package com.mycompany.ex3veiculo;

/**
 *
 * @author Vinicius
 */
public class Veiculo {
    public void acelerar() { 
        System.out.println("O veículo acelerou");
    }
    
    public void frear() {
        System.out.println("O veículo freou");
    }
}
