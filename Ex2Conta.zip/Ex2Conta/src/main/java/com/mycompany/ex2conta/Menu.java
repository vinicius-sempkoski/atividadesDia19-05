package com.mycompany.ex2conta;

/**
 *
 * @author Vinicius
 */
public class Menu {

    public static void main(String[] args) {
        Conta conta = new Conta();
        
        conta.setTitular("Vinicius");
        conta.setSaldo(9000);
        conta.depositar(50);
        conta.sacar(100);
        conta.obterSaldo();
        
        System.out.println("Titular: " + conta.getTitular());
    }
    
}
