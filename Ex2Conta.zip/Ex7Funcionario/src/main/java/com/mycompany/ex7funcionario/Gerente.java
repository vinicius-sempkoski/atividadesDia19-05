package com.mycompany.ex7funcionario;

/**
 *
 * @author Vinicius
 */
public class Gerente extends Funcionario {
    private String setor;

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }
}
