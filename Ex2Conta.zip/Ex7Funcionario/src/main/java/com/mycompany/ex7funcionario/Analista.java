package com.mycompany.ex7funcionario;

/**
 *
 * @author Vinicius
 */
public class Analista extends Funcionario {
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
