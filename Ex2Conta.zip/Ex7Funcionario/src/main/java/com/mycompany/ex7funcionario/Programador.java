package com.mycompany.ex7funcionario;

/**
 *
 * @author Vinicius
 */
public class Programador extends Funcionario {
    private String projeto;

    public String getProjeto() {
        return projeto;
    }

    public void setProjeto(String projeto) {
        this.projeto = projeto;
    }
}
