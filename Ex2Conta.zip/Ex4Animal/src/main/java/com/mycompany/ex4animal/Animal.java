package com.mycompany.ex4animal;

/**
 *
 * @author Vinicius
 */
public abstract class Animal {
    public abstract void emitirSom();
    public abstract void mover();
}
