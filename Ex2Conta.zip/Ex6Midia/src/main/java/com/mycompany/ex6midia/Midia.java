package com.mycompany.ex6midia;

/**
 *
 * @author Vinicius
 */
public class Midia {
    public void reproduzir() {
        System.out.println("A mídia está sendo reproduzida");
    }
}
