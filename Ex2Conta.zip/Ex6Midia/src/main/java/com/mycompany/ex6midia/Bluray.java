package com.mycompany.ex6midia;

/**
 *
 * @author Vinicius
 */
public class Bluray extends Midia {
    @Override
    public void reproduzir() {
        System.out.println("O Blu-ray está sendo reproduzido");
    }
}
