package com.mycompany.ex6midia;

/**
 *
 * @author Vinicius
 */
public class Dvd extends Midia {
    @Override
    public void reproduzir() {
        System.out.println("O DVD está sendo reproduzido");
    }
}
