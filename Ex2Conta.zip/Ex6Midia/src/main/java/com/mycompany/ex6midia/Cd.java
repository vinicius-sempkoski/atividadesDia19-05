package com.mycompany.ex6midia;

/**
 *
 * @author Vinicius
 */
public class Cd extends Midia {
    @Override
    public void reproduzir() {
        System.out.println("O CD está sendo reproduzido");
    } 
}
