package com.mycompany.ex8autenticavel;

/**
 *
 * @author Vinicius
 */
public class Autenticavel {
    public void autenticar() {
        System.out.println("Está autenticado");
    }
    
    public void desautenticar() {
        System.out.println("Está desautenticado");
    }
}
