package com.mycompany.ex8autenticavel;

/**
 *
 * @author Vinicius
 */
public class Menu {

    public static void main(String[] args) {
        SistemaSeguro sist = new SistemaSeguro();
        sist.setAutentico(false);
        sist.autenticar();
        sist.desautenticar();
    }
}
