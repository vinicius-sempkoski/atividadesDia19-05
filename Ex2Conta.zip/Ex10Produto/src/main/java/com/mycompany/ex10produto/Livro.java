package com.mycompany.ex10produto;

/**
 *
 * @author Vinicius
 */
public class Livro extends Produto {
    private String autor;

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
}
