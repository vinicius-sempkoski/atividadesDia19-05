package com.mycompany.ex10produto;

/**
 *
 * @author Vinicius
 */
public class Eletronico extends Produto {
    private String cor;

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
}
