package com.mycompany.ex10produto;

/**
 *
 * @author Vinicius
 */
public class Roupa extends Produto {
    private String tamanho;

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }
}
