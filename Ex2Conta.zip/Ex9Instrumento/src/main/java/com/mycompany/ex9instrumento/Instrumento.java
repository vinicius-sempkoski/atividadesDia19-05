package com.mycompany.ex9instrumento;

/**
 *
 * @author Vinicius
 */
public abstract class Instrumento {
    public abstract void tocar();
}
