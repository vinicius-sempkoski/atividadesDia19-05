package com.mycompany.ex9instrumento;

/**
 *
 * @author Vinicius
 */
public class Violao extends Instrumento {
    @Override
    public void tocar() {
        System.out.println("O violão está sendo tocado");
    }  
}
