package com.mycompany.ex1shape;

/**
 *
 * @author Vinicius
 */
public class Shape {
    public double calcularArea() {  
        return 0;     
    }
    
    public double calcularPerimetro() {     
        return 0; 
    }
}
